Forked from etcd 2.2 release branch to support migration from 3.0 WAL to 2.2 WAL format
