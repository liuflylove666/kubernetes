Forked from etcd 2.3 release branch to support migration from 3.0 WAL to 2.3 WAL format
